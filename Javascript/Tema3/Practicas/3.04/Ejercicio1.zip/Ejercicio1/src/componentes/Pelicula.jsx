function Pelicula(props) {
    return (
    <>
        <h1>{props.nombre}</h1>
        <h2>Escrita y dirigida por {props.director}</h2>
        <p>{props.children}</p>
        <div className="elenco">
            <img src={props.cartelera} width={500}/>
            <article>
                <section>
                    <h3>{props.actores}</h3>
                    <img src={props.imagen} alt={props.actor} width={300}/>
                </section>
                <p>{props.children}</p>
            </article>
        </div>
    </>
    );
}