import { generarUuidAleatorio } from '/Users/Kaladin/Downloads/2DAW/2DAW/Javascript/Tema3/Practicas/3.04/Ejercicio1/src/bibliotecas/funciones.js'

generarUuidAleatorio