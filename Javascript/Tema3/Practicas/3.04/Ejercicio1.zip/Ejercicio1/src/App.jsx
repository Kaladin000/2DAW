import peliculas from './objetos/peliculas.json'
import Pelicula from './componentes/Pelicula.jsx'

function App(props) {
  return (
    <>
      <Pelicula>
      </Pelicula>
    </>
  );
}

export default App;
