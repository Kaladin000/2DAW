"use strict";
import "./style.css"
import { funcionalidadPrincipal } from "./biblioteca.js";

window.onload = function () {
  funcionalidadPrincipal();
};
