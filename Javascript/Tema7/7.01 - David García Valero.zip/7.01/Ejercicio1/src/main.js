"use strict";
import "./style.css"
import { funcionalidadPrincipal } from "./biblioteca.js";

window.onload = function () {
  funcionalidadPrincipal();
  console.log("¡Viva JavaScript!".repetir(0));
  console.log("¡Viva JavaScript!".repetir(5));
};
